var struct_sl_net_app_dhcp_server_basic_opt__t =
[
    [ "ipv4_addr_last", "struct_sl_net_app_dhcp_server_basic_opt__t.html#a3658ee49e477ac75294c4dcb44e9469b", null ],
    [ "ipv4_addr_start", "struct_sl_net_app_dhcp_server_basic_opt__t.html#ad89c28578421c014b62f5edd796760b1", null ],
    [ "lease_time", "struct_sl_net_app_dhcp_server_basic_opt__t.html#ae870c09512e5404d8fd6a94d899d52b5", null ]
];