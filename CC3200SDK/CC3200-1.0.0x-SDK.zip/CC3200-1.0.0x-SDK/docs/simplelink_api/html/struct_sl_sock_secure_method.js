var struct_sl_sock_secure_method =
[
    [ "secureMethod", "struct_sl_sock_secure_method.html#a7b920ea3f38a2399d1aa2c473cf1021e", null ]
];