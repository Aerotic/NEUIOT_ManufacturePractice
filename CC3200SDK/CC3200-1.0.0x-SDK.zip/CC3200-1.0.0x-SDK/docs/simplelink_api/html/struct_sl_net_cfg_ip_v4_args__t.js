var struct_sl_net_cfg_ip_v4_args__t =
[
    [ "ipV4", "struct_sl_net_cfg_ip_v4_args__t.html#a47731711b8c0c195ca46de2e938364d3", null ],
    [ "ipV4DnsServer", "struct_sl_net_cfg_ip_v4_args__t.html#a920eac2941ede0d5a676d59ea8319a56", null ],
    [ "ipV4Gateway", "struct_sl_net_cfg_ip_v4_args__t.html#ae5dd0932c0fc590f70c116dae8c56b07", null ],
    [ "ipV4Mask", "struct_sl_net_cfg_ip_v4_args__t.html#af37ed58288d015f7869dbfa8b566eec1", null ]
];