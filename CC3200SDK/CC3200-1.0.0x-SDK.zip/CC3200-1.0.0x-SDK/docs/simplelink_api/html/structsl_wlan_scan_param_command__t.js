var structsl_wlan_scan_param_command__t =
[
    [ "G_Channels_mask", "structsl_wlan_scan_param_command__t.html#a1401545f73ec1aeb0f1caff176a49877", null ],
    [ "rssiThershold", "structsl_wlan_scan_param_command__t.html#a12b902a2708b47b806a727a2604f9c4f", null ]
];