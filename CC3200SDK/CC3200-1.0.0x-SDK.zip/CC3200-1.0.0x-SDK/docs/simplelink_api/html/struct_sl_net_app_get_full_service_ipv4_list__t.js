var struct_sl_net_app_get_full_service_ipv4_list__t =
[
    [ "Reserved", "struct_sl_net_app_get_full_service_ipv4_list__t.html#a3f5363b14f728fe990328585ccbc70e1", null ],
    [ "service_host", "struct_sl_net_app_get_full_service_ipv4_list__t.html#aeb85c9d6321692e2622077406052c2c2", null ],
    [ "service_ipv4", "struct_sl_net_app_get_full_service_ipv4_list__t.html#a1a2075c35d52286cb696f878738d30be", null ],
    [ "service_name", "struct_sl_net_app_get_full_service_ipv4_list__t.html#a14a68e63be446395d1bdc960d9cd46bb", null ],
    [ "service_port", "struct_sl_net_app_get_full_service_ipv4_list__t.html#a526174fd4b7f339328e315dbb01c19f7", null ]
];