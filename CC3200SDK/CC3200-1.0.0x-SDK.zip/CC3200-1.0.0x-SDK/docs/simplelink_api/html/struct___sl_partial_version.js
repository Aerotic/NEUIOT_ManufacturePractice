var struct___sl_partial_version =
[
    [ "ChipId", "struct___sl_partial_version.html#a877d3a1147d35755dbce8176048ce947", null ],
    [ "FwVersion", "struct___sl_partial_version.html#a59bd6f51689f540b0ba4dc785e4bfb64", null ],
    [ "PhyVersion", "struct___sl_partial_version.html#ac5605d53799a6c74ac3f37559c465edb", null ]
];