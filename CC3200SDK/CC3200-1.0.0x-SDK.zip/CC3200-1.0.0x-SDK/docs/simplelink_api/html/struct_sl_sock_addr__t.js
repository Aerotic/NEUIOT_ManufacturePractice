var struct_sl_sock_addr__t =
[
    [ "sa_data", "struct_sl_sock_addr__t.html#ae2b1f612104f3b2e3986fec7cc8b434b", null ],
    [ "sa_family", "struct_sl_sock_addr__t.html#a2ec201dde0ef6487c4d40b54bb193f8d", null ]
];