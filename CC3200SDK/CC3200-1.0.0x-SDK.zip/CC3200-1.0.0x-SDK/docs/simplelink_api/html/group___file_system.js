var group___file_system =
[
    [ "SlFsFileInfo_t", "struct_sl_fs_file_info__t.html", [
      [ "AllocatedLen", "struct_sl_fs_file_info__t.html#a1888c786f5e31740d464bd7d88773e4b", null ],
      [ "FileLen", "struct_sl_fs_file_info__t.html#a42e92a9d18f2642049165db21a2bfe82", null ],
      [ "flags", "struct_sl_fs_file_info__t.html#ac19f310fccda9703415c584f0a7497f4", null ],
      [ "Token", "struct_sl_fs_file_info__t.html#abdf1173d4d93434f8a910e0f84987463", null ]
    ] ],
    [ "sl_FsClose", "group___file_system.html#gadcea87bf2342174220435d564b894a42", null ],
    [ "sl_FsDel", "group___file_system.html#ga08228317c6090bb2ce1eca508acb1f35", null ],
    [ "sl_FsGetInfo", "group___file_system.html#gae3ebf3e8ef6f34ff9e3fe97e5370aa1c", null ],
    [ "sl_FsOpen", "group___file_system.html#ga6a9aaae1813255fa13c7d6bc26c2904c", null ],
    [ "sl_FsRead", "group___file_system.html#ga62835b890b9f9992c3db60119a627dbc", null ],
    [ "sl_FsWrite", "group___file_system.html#ga32f5957d3f53ea68d1c2c80e2e2b6787", null ]
];