var group__netcfg =
[
    [ "SlNetCfgIpV4Args_t", "struct_sl_net_cfg_ip_v4_args__t.html", [
      [ "ipV4", "struct_sl_net_cfg_ip_v4_args__t.html#a47731711b8c0c195ca46de2e938364d3", null ],
      [ "ipV4DnsServer", "struct_sl_net_cfg_ip_v4_args__t.html#a920eac2941ede0d5a676d59ea8319a56", null ],
      [ "ipV4Gateway", "struct_sl_net_cfg_ip_v4_args__t.html#ae5dd0932c0fc590f70c116dae8c56b07", null ],
      [ "ipV4Mask", "struct_sl_net_cfg_ip_v4_args__t.html#af37ed58288d015f7869dbfa8b566eec1", null ]
    ] ],
    [ "sl_NetCfgGet", "group__netcfg.html#gaae48efdddc313517b86d25d819f10b24", null ],
    [ "sl_NetCfgSet", "group__netcfg.html#gab199703b982451676f7c5bdb344ec4ef", null ]
];