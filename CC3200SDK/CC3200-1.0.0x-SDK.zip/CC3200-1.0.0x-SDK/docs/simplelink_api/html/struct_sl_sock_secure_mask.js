var struct_sl_sock_secure_mask =
[
    [ "secureMask", "struct_sl_sock_secure_mask.html#a60798538f913579423ecfac09c9e13d7", null ]
];