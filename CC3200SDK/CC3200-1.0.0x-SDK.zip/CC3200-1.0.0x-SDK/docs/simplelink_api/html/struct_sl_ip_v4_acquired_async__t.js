var struct_sl_ip_v4_acquired_async__t =
[
    [ "dns", "struct_sl_ip_v4_acquired_async__t.html#aad25be6b70d3ea82fd985d8b48897883", null ],
    [ "gateway", "struct_sl_ip_v4_acquired_async__t.html#a269bb91b6feb081352eedf250664de16", null ],
    [ "ip", "struct_sl_ip_v4_acquired_async__t.html#af1a8503514e9d113c83fe28f8822fa16", null ]
];