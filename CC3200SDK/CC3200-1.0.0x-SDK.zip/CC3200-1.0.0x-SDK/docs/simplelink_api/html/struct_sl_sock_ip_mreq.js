var struct_sl_sock_ip_mreq =
[
    [ "imr_interface", "struct_sl_sock_ip_mreq.html#a526726f1171c79d8003490ab86f3da7c", null ],
    [ "imr_multiaddr", "struct_sl_sock_ip_mreq.html#a6a0c67f0fbae8c3d98c1913f2d37b200", null ]
];