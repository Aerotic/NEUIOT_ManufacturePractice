var struct_sl_net_app_get_short_service_ipv4_list__t =
[
    [ "Reserved", "struct_sl_net_app_get_short_service_ipv4_list__t.html#a3f5363b14f728fe990328585ccbc70e1", null ],
    [ "service_ipv4", "struct_sl_net_app_get_short_service_ipv4_list__t.html#a1a2075c35d52286cb696f878738d30be", null ],
    [ "service_port", "struct_sl_net_app_get_short_service_ipv4_list__t.html#a526174fd4b7f339328e315dbb01c19f7", null ]
];