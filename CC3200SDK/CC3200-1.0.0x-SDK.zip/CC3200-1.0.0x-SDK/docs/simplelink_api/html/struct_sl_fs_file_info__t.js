var struct_sl_fs_file_info__t =
[
    [ "AllocatedLen", "struct_sl_fs_file_info__t.html#a1888c786f5e31740d464bd7d88773e4b", null ],
    [ "FileLen", "struct_sl_fs_file_info__t.html#a42e92a9d18f2642049165db21a2bfe82", null ],
    [ "flags", "struct_sl_fs_file_info__t.html#ac19f310fccda9703415c584f0a7497f4", null ],
    [ "Token", "struct_sl_fs_file_info__t.html#abdf1173d4d93434f8a910e0f84987463", null ]
];