var struct_sl_device_event__t =
[
    [ "Event", "struct_sl_device_event__t.html#adeedbaaa252b969fc66e151eef37ea62", null ],
    [ "EventData", "struct_sl_device_event__t.html#ad8c1d9df20f3a61d8c0f1b7aba495af7", null ]
];