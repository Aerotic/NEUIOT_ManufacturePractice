var struct_sl_sock_addr_in__t =
[
    [ "sin_addr", "struct_sl_sock_addr_in__t.html#ac202531c3497bcb9d64a83028f036d81", null ],
    [ "sin_family", "struct_sl_sock_addr_in__t.html#a073756b1c41885b395510a04d5e8e108", null ],
    [ "sin_port", "struct_sl_sock_addr_in__t.html#a591c70234168b0d4509cadef8b6d3ea1", null ],
    [ "sin_zero", "struct_sl_sock_addr_in__t.html#a46c3a43fbd9a84363466a5ea60c08440", null ]
];