var struct_sl_ip_released_async__t =
[
    [ "ip_address", "struct_sl_ip_released_async__t.html#aba21cfc12ca7e52b24d4566825a69583", null ],
    [ "mac", "struct_sl_ip_released_async__t.html#a51fa48efb76fa1995446db52ac06a46f", null ],
    [ "reason", "struct_sl_ip_released_async__t.html#a74c4b0fa5b3987eb1c1c38d1328800ec", null ]
];