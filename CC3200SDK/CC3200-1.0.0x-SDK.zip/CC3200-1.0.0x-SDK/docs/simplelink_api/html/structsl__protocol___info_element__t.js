var structsl__protocol___info_element__t =
[
    [ "data", "structsl__protocol___info_element__t.html#a27e0ca8e8af28ff69c2df264599f5625", null ],
    [ "id", "structsl__protocol___info_element__t.html#a2888afcbf466934238f060ea0b8300ed", null ],
    [ "length", "structsl__protocol___info_element__t.html#a128a630f6d2121a0106add0f03f1cab9", null ],
    [ "oui", "structsl__protocol___info_element__t.html#aa7158dccffcbe48160a5c4ac033466ff", null ]
];