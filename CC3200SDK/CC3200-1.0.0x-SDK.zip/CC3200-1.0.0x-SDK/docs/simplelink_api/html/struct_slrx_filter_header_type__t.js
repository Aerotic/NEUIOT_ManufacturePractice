var struct_slrx_filter_header_type__t =
[
    [ "RuleCompareFunc", "struct_slrx_filter_header_type__t.html#aa92cfd1d32af09ab6c845ced96c4110f", null ],
    [ "RuleHeaderArgsAndMask", "struct_slrx_filter_header_type__t.html#afb384f375f43a8cb7e349ffaf70c26e6", null ],
    [ "RuleHeaderfield", "struct_slrx_filter_header_type__t.html#ac40cef42995351984232b29151bc0b6c", null ],
    [ "RulePadding", "struct_slrx_filter_header_type__t.html#aab0c11c64eed544d5fb67de89249c6fa", null ]
];