var struct_sl_sec_params__t =
[
    [ "Key", "struct_sl_sec_params__t.html#af943e0f6d7ca78a5b795c8da294c5d1e", null ],
    [ "KeyLen", "struct_sl_sec_params__t.html#a9b049837934488d32481cf8d616e12af", null ],
    [ "Type", "struct_sl_sec_params__t.html#a1d58ad89ed5b340d15c354b769f8ecc2", null ]
];