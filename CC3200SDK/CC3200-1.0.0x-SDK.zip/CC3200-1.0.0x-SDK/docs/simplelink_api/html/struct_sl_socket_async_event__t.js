var struct_sl_socket_async_event__t =
[
    [ "sd", "struct_sl_socket_async_event__t.html#a6e61459b1cc5e37bbd460cbbdade7fd0", null ],
    [ "type", "struct_sl_socket_async_event__t.html#a525a5ef247f93f470f4f5e2b5cc59dce", null ],
    [ "val", "struct_sl_socket_async_event__t.html#ad8afa2d0f076cad9c84b3c1e9022fbd6", null ]
];