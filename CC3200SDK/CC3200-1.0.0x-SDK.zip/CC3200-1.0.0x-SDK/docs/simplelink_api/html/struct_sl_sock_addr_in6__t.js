var struct_sl_sock_addr_in6__t =
[
    [ "sin6_addr", "struct_sl_sock_addr_in6__t.html#ab80273cf64088fdcf85aca765997b845", null ],
    [ "sin6_family", "struct_sl_sock_addr_in6__t.html#a1353901c9555ac56c1ca22dc1533c3b8", null ],
    [ "sin6_flowinfo", "struct_sl_sock_addr_in6__t.html#afba686aa3c6f6242cac4d29bc7c7d558", null ],
    [ "sin6_port", "struct_sl_sock_addr_in6__t.html#ad7c0b531025d2975102172b2398611f5", null ],
    [ "sin6_scope_id", "struct_sl_sock_addr_in6__t.html#a95780ab290350f365e6de5dba3af0032", null ]
];