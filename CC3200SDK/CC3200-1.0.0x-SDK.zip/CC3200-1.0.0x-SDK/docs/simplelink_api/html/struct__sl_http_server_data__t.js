var struct__sl_http_server_data__t =
[
    [ "name_len", "struct__sl_http_server_data__t.html#a295865b2d6f6091bc35d8de6e8cae731", null ],
    [ "token_name", "struct__sl_http_server_data__t.html#adff3bc96f451530f4776b011f36a3c2a", null ],
    [ "token_value", "struct__sl_http_server_data__t.html#a2283b20c750664ec3b4301cb8e64f198", null ],
    [ "value_len", "struct__sl_http_server_data__t.html#ae6d3f66fb64a31cc12909a1ec028387b", null ]
];