var searchData=
[
  ['_5fsllockobj_5ft',['_SlLockObj_t',['../group__configuration__os.html#ga8d2ec9002b5c79f7ff4078131bd2cf75',1,'user.h']]],
  ['_5fslsyncobj_5ft',['_SlSyncObj_t',['../group__configuration__os.html#gaf276f690a7bcfca16d38b279d1229472',1,'user.h']]]
];
