var struct_sl_date_time__t =
[
    [ "reserved", "struct_sl_date_time__t.html#a49f5795062d81178ce89f77d61448bee", null ],
    [ "sl_tm_day", "struct_sl_date_time__t.html#af83ea24b23158f14e96ff93c5e8c0896", null ],
    [ "sl_tm_hour", "struct_sl_date_time__t.html#a92f8e6dd9aa31ef8fb286c5c2c0c34b9", null ],
    [ "sl_tm_min", "struct_sl_date_time__t.html#ac9111faf20f5af837320742ad9654226", null ],
    [ "sl_tm_mon", "struct_sl_date_time__t.html#aa898a97b5759e5020905a464619003d1", null ],
    [ "sl_tm_sec", "struct_sl_date_time__t.html#a000a13e33ea38c8e0bb5541f3723126d", null ],
    [ "sl_tm_week_day", "struct_sl_date_time__t.html#a5171f9a27af9cba0e6ef95d9af2eed07", null ],
    [ "sl_tm_year", "struct_sl_date_time__t.html#ac214aa05234cf1c38cbc1e464997c25e", null ],
    [ "sl_tm_year_day", "struct_sl_date_time__t.html#a041e83bc571abb3b79165cbf6bea74a1", null ]
];