var struct_sl_sock_winsize__t =
[
    [ "Winsize", "struct_sl_sock_winsize__t.html#af706421c801e172c074064414e837eec", null ]
];