var struct_sl_transceiver_rx_over_head__t =
[
    [ "channel", "struct_sl_transceiver_rx_over_head__t.html#aa884a666899783e8d3f3d4921b0a24c3", null ],
    [ "padding", "struct_sl_transceiver_rx_over_head__t.html#add68adbd81b0e5a99dda8bd7b4481108", null ],
    [ "rate", "struct_sl_transceiver_rx_over_head__t.html#a953f0299b419ccb222c1c7ef8320ff51", null ],
    [ "rssi", "struct_sl_transceiver_rx_over_head__t.html#a80c3df13ed7cf0b1a5e5639811c82f34", null ],
    [ "timestamp", "struct_sl_transceiver_rx_over_head__t.html#ae583290c9ab9f4aa0275b90ed56de3c4", null ]
];