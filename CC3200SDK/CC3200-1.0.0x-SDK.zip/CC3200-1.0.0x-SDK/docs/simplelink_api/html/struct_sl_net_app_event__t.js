var struct_sl_net_app_event__t =
[
    [ "Event", "struct_sl_net_app_event__t.html#adeedbaaa252b969fc66e151eef37ea62", null ],
    [ "EventData", "struct_sl_net_app_event__t.html#ac58cdb6e0d008f951c65fade86f32713", null ]
];