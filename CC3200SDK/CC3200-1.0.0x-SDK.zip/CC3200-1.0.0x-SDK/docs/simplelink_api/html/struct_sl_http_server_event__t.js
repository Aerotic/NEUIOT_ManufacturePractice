var struct_sl_http_server_event__t =
[
    [ "Event", "struct_sl_http_server_event__t.html#adeedbaaa252b969fc66e151eef37ea62", null ],
    [ "EventData", "struct_sl_http_server_event__t.html#aea6d012a43dcb8ded6b90686ceaef0f7", null ]
];