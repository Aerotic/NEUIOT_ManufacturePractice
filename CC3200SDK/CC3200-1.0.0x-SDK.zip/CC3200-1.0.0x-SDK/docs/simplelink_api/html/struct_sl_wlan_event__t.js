var struct_sl_wlan_event__t =
[
    [ "Event", "struct_sl_wlan_event__t.html#adeedbaaa252b969fc66e151eef37ea62", null ],
    [ "EventData", "struct_sl_wlan_event__t.html#ae587c51197255d4e4ef20cc90d73825f", null ]
];