var struct_sl_http_server_response__t =
[
    [ "Response", "struct_sl_http_server_response__t.html#acc4e0dc6756b696c4e2bbdd3f75d1123", null ],
    [ "ResponseData", "struct_sl_http_server_response__t.html#a79b6c5114e9f6da69c3113d4be87a943", null ]
];