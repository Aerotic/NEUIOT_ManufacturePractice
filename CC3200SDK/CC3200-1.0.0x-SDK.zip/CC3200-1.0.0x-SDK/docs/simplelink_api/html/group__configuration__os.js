var group__configuration__os =
[
    [ "_SlTime_t", "group__configuration__os.html#ga2b59ba700928c882ee7e09cc2ca21ae0", null ],
    [ "sl_LockObjCreate", "group__configuration__os.html#gac1d0a12a5afd13d8b7809911c645fd5c", null ],
    [ "sl_LockObjDelete", "group__configuration__os.html#ga6ac346506983bdee1f92bf25be6242d8", null ],
    [ "sl_LockObjLock", "group__configuration__os.html#ga53c6c1fb7069626627b59ed2ac526f37", null ],
    [ "sl_LockObjUnlock", "group__configuration__os.html#gae4e01547906364515ec4ed1efd07020c", null ],
    [ "SL_OS_NO_WAIT", "group__configuration__os.html#gab3addb759397657f08d76f9a8d911df3", null ],
    [ "SL_OS_RET_CODE_OK", "group__configuration__os.html#gab7a5fd0efc65395fb4a08a373d5b2249", null ],
    [ "SL_OS_WAIT_FOREVER", "group__configuration__os.html#ga46fef31825e3d93f0cbf87ef0f0e8bdc", null ],
    [ "SL_PLATFORM_EXTERNAL_SPAWN", "group__configuration__os.html#gab5eaa3977a30d7850822d02d59177134", null ],
    [ "sl_SyncObjCreate", "group__configuration__os.html#ga8c0d4537932fc4d16fdb74b47c87f25c", null ],
    [ "sl_SyncObjDelete", "group__configuration__os.html#ga7c3a3039c187e241dc672012283a1dbd", null ],
    [ "sl_SyncObjSignal", "group__configuration__os.html#gafd412ee7243ea29192ab6156e5dae006", null ],
    [ "sl_SyncObjSignalFromIRQ", "group__configuration__os.html#ga8a675ba872a3baab12ba0061d0438497", null ],
    [ "sl_SyncObjWait", "group__configuration__os.html#gad6449455165bec5c40eb0a1b399e285a", null ],
    [ "_SlLockObj_t", "group__configuration__os.html#ga8d2ec9002b5c79f7ff4078131bd2cf75", null ],
    [ "_SlSyncObj_t", "group__configuration__os.html#gaf276f690a7bcfca16d38b279d1229472", null ]
];