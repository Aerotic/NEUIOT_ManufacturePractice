var structsl___device_report =
[
    [ "sender", "structsl___device_report.html#ac0b67f727ab542ea92d7bb5a9586c638", null ],
    [ "status", "structsl___device_report.html#aea15cd487dbeb2bdf9c07ef8d864c64e", null ]
];