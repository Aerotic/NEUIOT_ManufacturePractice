var structsl_wlan_connect_async_response__t =
[
    [ "bssid", "structsl_wlan_connect_async_response__t.html#a26584d70e5f1888864c8c3f3d43e21c7", null ],
    [ "connection_type", "structsl_wlan_connect_async_response__t.html#a02de4ebfc0ae3ef0524521fea6cdba7a", null ],
    [ "go_peer_device_name", "structsl_wlan_connect_async_response__t.html#a134cf4c828e548efdc5febe2b8b826ae", null ],
    [ "go_peer_device_name_len", "structsl_wlan_connect_async_response__t.html#ad58b0d3c676c06221fa491ec4b384cad", null ],
    [ "padding", "structsl_wlan_connect_async_response__t.html#a591a340cf7a3bc8395dc554fc01910b7", null ],
    [ "reason_code", "structsl_wlan_connect_async_response__t.html#aef3e37e4643200170981d36287a9bbf5", null ],
    [ "ssid_len", "structsl_wlan_connect_async_response__t.html#a2e45fb530d9c89d3673ea6e05f07844d", null ],
    [ "ssid_name", "structsl_wlan_connect_async_response__t.html#a89e1ad338d707b4182bd0a8bf5a15bc6", null ]
];