var structsock__secure_files =
[
    [ "secureFiles", "structsock__secure_files.html#ac65e78cc8df4ee675c0f86d9572be2a5", null ]
];