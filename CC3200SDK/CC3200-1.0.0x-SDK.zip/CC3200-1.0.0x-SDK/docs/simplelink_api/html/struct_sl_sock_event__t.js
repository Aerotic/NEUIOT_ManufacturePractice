var struct_sl_sock_event__t =
[
    [ "Event", "struct_sl_sock_event__t.html#adeedbaaa252b969fc66e151eef37ea62", null ],
    [ "EventData", "struct_sl_sock_event__t.html#a3b2d881ad4bcc5cee8a09ea2e3a9e364", null ]
];