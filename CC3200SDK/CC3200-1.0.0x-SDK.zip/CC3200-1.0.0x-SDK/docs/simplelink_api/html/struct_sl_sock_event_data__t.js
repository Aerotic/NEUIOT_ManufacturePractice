var struct_sl_sock_event_data__t =
[
    [ "sd", "struct_sl_sock_event_data__t.html#a7bcf1a1a2604db78219a22c1133662f1", null ],
    [ "socketAsyncEvent", "struct_sl_sock_event_data__t.html#ade95cf432a38a6ee899c7e9b69a06d83", null ],
    [ "status", "struct_sl_sock_event_data__t.html#a88b0e46c9227c27bb67842b895edbc6f", null ]
];