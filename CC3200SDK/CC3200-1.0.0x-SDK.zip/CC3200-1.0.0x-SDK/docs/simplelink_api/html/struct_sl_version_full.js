var struct_sl_version_full =
[
    [ "ChipFwAndPhyVersion", "struct_sl_version_full.html#ad5ea7f4ad7fbeb5a94ac66e2da5d55db", null ],
    [ "NwpVersion", "struct_sl_version_full.html#a70e21c342f3050f69fba55d461ccec8c", null ],
    [ "Padding", "struct_sl_version_full.html#a3e6fcab66830b3ba1b3d8d6167595d03", null ],
    [ "RomVersion", "struct_sl_version_full.html#a04d0b5c1e5fe2e3e1209bafd6f6d6596", null ]
];