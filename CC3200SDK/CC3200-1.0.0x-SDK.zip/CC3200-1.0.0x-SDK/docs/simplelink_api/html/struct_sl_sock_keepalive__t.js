var struct_sl_sock_keepalive__t =
[
    [ "KeepaliveEnabled", "struct_sl_sock_keepalive__t.html#aac43eef83958917bdf29de10afae4a00", null ]
];