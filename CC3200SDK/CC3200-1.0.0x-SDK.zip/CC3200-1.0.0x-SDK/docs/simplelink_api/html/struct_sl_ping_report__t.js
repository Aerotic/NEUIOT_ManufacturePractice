var struct_sl_ping_report__t =
[
    [ "AvgRoundTime", "struct_sl_ping_report__t.html#a5d610bdde4039525984224ee0f35b6d9", null ],
    [ "MaxRoundTime", "struct_sl_ping_report__t.html#abb8b750ec3b99bcac2b1a84c611c6d2a", null ],
    [ "MinRoundTime", "struct_sl_ping_report__t.html#a10437a22b3604a1fbe4cb91bd711077f", null ],
    [ "PacketsReceived", "struct_sl_ping_report__t.html#ac8e9ea566ef6bd2acb54a6af9677486a", null ],
    [ "PacketsSent", "struct_sl_ping_report__t.html#a92813cdd58af8c15929270ccf61b26a2", null ],
    [ "TestTime", "struct_sl_ping_report__t.html#af7da9681c2b355a3261a476f353bfe93", null ]
];