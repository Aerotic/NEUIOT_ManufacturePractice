var struct__sl_http_server_string__t =
[
    [ "data", "struct__sl_http_server_string__t.html#ae2f1a2294cac364e7901e04f5821ede8", null ],
    [ "len", "struct__sl_http_server_string__t.html#acc9fcad2930f408ce8147134702a4ff3", null ]
];